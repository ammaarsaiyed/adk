---
name: migrate-adk-python-1-to-2
description: Audit, plan, and implement migrations of Python projects from Google Agent Development Kit (ADK) 1.x to 2.x, including breaking API and event/session changes and architecture decisions among ordinary agents, graph workflows, dynamic workflows, template workflows, and collaborative subagent teams. Use for ADK Python major-version upgrades or redesigns; do not use for TypeScript, Go, Java, or Kotlin migrations.
metadata:
  short-description: Migrate ADK Python 1.x projects to 2.x safely
---

# Migrate ADK Python 1.x to 2.x

Treat this as a behavior-preserving migration with an explicit architecture decision, not as an import rewrite. ADK 2.x is broadly compatible with ordinary 1.x agents, but custom execution, event persistence, session schemas, exception handling, and orchestration can require real redesign.

## Source authority

Use API facts only after checking the target 2.x version against, in order:

1. The installed `google-adk` package or an isolated environment pinned to the proposed version.
2. The matching `google/adk-python` release/tag and official API docs.
3. Current `adk.dev` guides and `google/adk-samples`.

Official main-branch examples can be ahead of the selected release. Do not use community examples as API authority. Read [references/sources.md](references/sources.md) when facts may have changed or a symbol/signature is uncertain.

## Non-negotiable rules

- Preserve user-visible behavior, tool side effects, state scopes, event ordering requirements, and deployment contracts unless the user approves a redesign.
- Do not claim that ADK 1.x had no workflows. It had `SequentialAgent`, `ParallelAgent`, and `LoopAgent`; ADK 2.x adds graph and dynamic workflow models.
- Do not replace every `sub_agents=[...]`. ADK 2.x still documents collaborative coordinator/subagent teams. Replace agentic delegation only when the required control flow should be explicit.
- Deterministic orchestration does not make LLM inference deterministic. Test graph routes and code nodes deterministically; evaluate LLM behavior statistically or with rubric-based evals.
- Never append directly to `context.session.events` or call `enqueue_event` as an application-level emission path. Return or yield events through the runtime.
- Do not assume custom `BaseAgent` execution overrides still run. Migrate lifecycle concerns to supported callbacks and model orchestration as nodes/workflows.
- Do not swallow `BaseException`. Review broad `except Exception` blocks in interruptible or retried tools/nodes; catch only errors the code can resolve locally, otherwise re-raise.
- Do not force complex iterative or runtime-dependent control flow into an unreadable static graph. Choose a dynamic workflow when ordinary Python loops, branching, recursion, or runtime scheduling are the clearer model.
- Parallel terminal branches that produce outputs must converge through a `JoinNode` before workflow completion.
- Do not weaken, delete, or rewrite tests merely to obtain green results. Separate inherited failures, environment failures, and migration regressions.
- Do not invent plausible graph-runtime APIs by analogy with LangGraph or another SDK. Symbols such as modules, node wrappers, retry policies, session providers, and collaboration types must exist in the pinned ADK release.
- Do not deploy, migrate production data, or change cloud resources unless the user explicitly requested that external action.

## Choose the operating mode

Honor the request boundary:

- **Audit:** inspect and report only. Make no project changes.
- **Plan:** produce the inventory, architecture decision, migration ledger, verification plan, and rollback plan. Do not implement.
- **Implement:** perform the gated workflow below, stopping for choices that change product behavior, data compatibility, cost, or deployment topology.

If unclear, infer from the user's verb: “audit/review” means Audit, “plan” means Plan, and “migrate/upgrade/fix” means Implement.

## Gated workflow

### 1. Establish the judge before editing

Read [references/discovery-and-baseline.md](references/discovery-and-baseline.md). Capture:

- current and target ADK versions plus Python constraints;
- observable entry points, tools, session/state backends, clients, and deployment targets;
- a baseline from tests, ADK evals, sanitized traces, or a small parity harness;
- known inherited failures and environment-dependent checks.

No trustworthy baseline means no trustworthy claim of parity. For redesign migrations, judge the public behavior, not internal call sequences that the redesign intentionally changes.

### 2. Build the migration inventory

Run the bundled read-only scanner when local execution is available:

```bash
python /path/to/this-skill/scripts/audit_adk_migration.py . --format markdown
```

Read its findings as leads, not proof. Confirm each critical finding in source. Supplement with repository search, dependency inspection, tests, schemas, deployment manifests, and client contracts.

### 3. Decide whether this is an upgrade or a redesign

Read [references/architecture-decision.md](references/architecture-decision.md) and [references/anti-rationalization.md](references/anti-rationalization.md). Classify product control rules separately from generative reasoning, then select one target per orchestration boundary:

- ordinary `Agent`/`LlmAgent` compatibility upgrade;
- retained template workflow;
- static graph `Workflow`;
- dynamic durable workflow;
- collaborative coordinator/subagent team;
- a hybrid of deterministic workflow boundaries and LLM-driven nodes.

Write the decision and rejected alternatives before structural edits. A project may use different choices for different subsystems.

### 4. Make compatibility changes first

Read [references/breaking-changes.md](references/breaking-changes.md). In small, reviewable slices:

1. Pin a specific 2.x target and create/update the isolated environment.
2. Resolve import, type, callback-context, and event-construction compatibility.
3. Move unsupported custom execution overrides to supported callbacks/nodes.
4. Update Event consumers and rigid session storage for `node_info` and `output`.
5. Review exception propagation and introduce narrow `RetryConfig` policies where retry is safe.
6. Get imports, type checks, unit tests, and an ordinary agent smoke path passing before redesigning orchestration.

`agents-cli scaffold upgrade` upgrades an Agents CLI-generated scaffold. It is not an ADK 1→2 code migrator. Use it only when the project manifest proves the project is scaffold-managed and template synchronization is in scope; review its merge before accepting it.

### 5. Redesign orchestration only where justified

Read [references/api-patterns.md](references/api-patterns.md) for verified Python patterns. Preserve side-effect boundaries and idempotency. Prefer typed node inputs/outputs for within-run data flow; use session state for values that actually need session, user, app, or temporary scope.

For each slice, record:

| Field | Required content |
| --- | --- |
| Current behavior | Observable behavior and side effects |
| Risk | What can regress or replay incorrectly |
| Target primitive | Agent, graph, dynamic node, collaboration mode, callback, state, or Event |
| Data contract | Input/output/state schema and event/client impact |
| Proof | Unit, integration, eval, trace, or deployment check |
| Rollback | Revert, compatibility adapter, feature flag, or dual-run path |

Do not mix mechanical compatibility changes with a large architecture rewrite in one opaque patch.

### 6. Verify and report

Read [references/verification-and-rollout.md](references/verification-and-rollout.md). Minimum completion gates:

- the selected 2.x version imports and the project starts;
- graph construction and schema validation pass where applicable;
- deterministic nodes/routes, joins, retry boundaries, and resume behavior have focused tests;
- agent/tool behavior meets the agreed eval or parity bar;
- event/session serialization and every strict downstream consumer accept 2.x events;
- no confirmed critical scanner finding remains unexplained;
- deployment packaging is checked for the existing target, without deploying unless requested;
- rollback steps are executable and documented.

Return a concise migration report containing the target version, chosen architectures, changed surfaces, verification evidence, remaining risks, and deferred work. Never report “fully migrated” when only imports or compilation pass.

## Reference router

| Reference | Read when |
| --- | --- |
| [discovery-and-baseline.md](references/discovery-and-baseline.md) | Starting every audit, plan, or implementation |
| [architecture-decision.md](references/architecture-decision.md) | Classifying each orchestration boundary |
| [anti-rationalization.md](references/anti-rationalization.md) | Challenging shortcuts and over-broad migration rules |
| [breaking-changes.md](references/breaking-changes.md) | Reviewing compatibility and hard failure modes |
| [api-patterns.md](references/api-patterns.md) | Writing graph, dynamic, context, state, join, or retry code |
| [verification-and-rollout.md](references/verification-and-rollout.md) | Designing tests, cutover, and rollback |
| [sources.md](references/sources.md) | Revalidating version-sensitive facts and finding official docs |
