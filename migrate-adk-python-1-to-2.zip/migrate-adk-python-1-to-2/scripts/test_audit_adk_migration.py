#!/usr/bin/env python3
"""Self-test for audit_adk_migration.py using a disposable project."""

from __future__ import annotations

import tempfile
from pathlib import Path

from audit_adk_migration import collect, should_fail


FIXTURE = '''
from google.adk import BaseAgent, SequentialAgent
from google.adk.sessions import BaseSessionService
from google.adk.workflows import StepNode

class CustomAgent(BaseAgent):
    async def _run_async_impl(self, ctx):
        ctx.session.events.append("event")
        try:
            await ctx.enqueue_event("event")
        except BaseException:
            pass

class Store(BaseSessionService):
    pass

team = CustomAgent(
    name="team",
    instruction="First call the lookup tool, then delegate to writer.",
    sub_agents=[],
)
flow = SequentialAgent(name="flow", sub_agents=[team])

async def batch(runner, requests):
    for request in requests:
        try:
            await runner.run_async(request)
        except Exception:
            pass
'''


def main() -> int:
    with tempfile.TemporaryDirectory() as temp_dir:
        root = Path(temp_dir)
        (root / "agent.py").write_text(FIXTURE, encoding="utf-8")
        (root / "requirements.txt").write_text("google-adk==1.18.0\n", encoding="utf-8")
        findings, py_count, manifest_count = collect(root)

    codes = {finding.code for finding in findings}
    expected = {
        "ADK_DEPENDENCY",
        "BROAD_EXCEPTION",
        "CUSTOM_AGENT_EXECUTION",
        "DIRECT_EVENT_APPEND",
        "DIRECT_EVENT_ENQUEUE",
        "RUNNER_LOOP",
        "SESSION_SERVICE_CUSTOM",
        "SUB_AGENTS",
        "SWALLOWED_BASE_EXCEPTION",
        "TEMPLATE_WORKFLOW",
        "PROMPT_CONTROL_LANGUAGE",
        "UNVERIFIED_ADK_MODULE",
        "UNVERIFIED_ADK_SYMBOL",
    }
    missing = expected - codes
    assert not missing, f"missing findings: {sorted(missing)}"
    assert py_count == 1 and manifest_count == 1
    assert should_fail(findings, "critical")
    assert should_fail(findings, "attention")
    assert not should_fail([], "info")
    print(f"ok: {len(findings)} findings; all expected rules present")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
