#!/usr/bin/env python3
"""Read-only static inventory for Google ADK Python 1.x to 2.x migrations.

The scanner deliberately reports review leads, not automatic rewrites or proof of a
problem. It uses only the Python standard library so it can run before dependencies
are upgraded.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence


SKIP_DIRS = {
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "site-packages",
    "venv",
}

MANIFEST_NAMES = {
    "pyproject.toml",
    "requirements.txt",
    "requirements-dev.txt",
    "requirements-test.txt",
    "uv.lock",
    "poetry.lock",
    "Pipfile",
    "Pipfile.lock",
    "agents-cli-manifest.yaml",
}

SEVERITY_RANK = {"critical": 0, "attention": 1, "info": 2}

UNVERIFIED_ADK_SYMBOLS = {
    "AsyncPgSessionProvider",
    "AsyncSqliteSessionProvider",
    "ConditionalEdge",
    "RetryPolicy",
    "StepNode",
    "TaskAgent",
    "TaskRunner",
    "WorkflowRuntime",
}

PROMPT_CONTROL_PATTERN = re.compile(
    r"\b(first|then|next|only after|before (?:calling|running|delegating)|"
    r"must call|must delegate|delegate to|do not proceed until)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class Finding:
    severity: str
    code: str
    path: str
    line: int
    message: str


def dotted_name(node: ast.AST | None) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = dotted_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    if isinstance(node, ast.Call):
        return dotted_name(node.func)
    if isinstance(node, ast.Subscript):
        return dotted_name(node.value)
    return ""


def called_name(node: ast.Call) -> str:
    return dotted_name(node.func)


def inherits_named(node: ast.ClassDef, names: set[str]) -> bool:
    return any(dotted_name(base).split(".")[-1] in names for base in node.bases)


def keyword_names(node: ast.Call) -> set[str]:
    return {keyword.arg for keyword in node.keywords if keyword.arg is not None}


class PythonAudit(ast.NodeVisitor):
    def __init__(self, relative_path: str) -> None:
        self.path = relative_path
        self.findings: list[Finding] = []
        self.class_stack: list[ast.ClassDef] = []
        self.loop_depth = 0

    def add(self, severity: str, code: str, node: ast.AST, message: str) -> None:
        self.findings.append(
            Finding(severity, code, self.path, getattr(node, "lineno", 1), message)
        )

    def visit_ClassDef(self, node: ast.ClassDef) -> None:  # noqa: N802
        bases = {dotted_name(base).split(".")[-1] for base in node.bases}
        if "BaseSessionService" in bases:
            self.add(
                "critical",
                "SESSION_SERVICE_CUSTOM",
                node,
                "Custom BaseSessionService: verify storage accepts ADK 2 Event node_info/output fields.",
            )
        if bases & {"BaseAgent", "Agent", "LlmAgent"}:
            overrides = {
                child.name
                for child in node.body
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
                and child.name in {"_run_async_impl", "generate_content"}
            }
            if overrides:
                names = ", ".join(sorted(overrides))
                self.add(
                    "critical",
                    "CUSTOM_AGENT_EXECUTION",
                    node,
                    f"Custom agent overrides {names}; move lifecycle/orchestration to supported callbacks or nodes.",
                )
        self.class_stack.append(node)
        self.generic_visit(node)
        self.class_stack.pop()

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:  # noqa: N802
        module = node.module or ""
        if module == "google.adk.workflows":
            self.add(
                "attention",
                "UNVERIFIED_ADK_MODULE",
                node,
                "Import from google.adk.workflows: reviewed Python 2.x docs use google.adk.workflow (singular) for graph helpers.",
            )
        if module.startswith("google.adk"):
            for alias in node.names:
                if alias.name in UNVERIFIED_ADK_SYMBOLS:
                    self.add(
                        "attention",
                        "UNVERIFIED_ADK_SYMBOL",
                        node,
                        f"{alias.name} is not a documented Python 2.0 construct in the reviewed official examples; verify the pinned release.",
                    )
        self.generic_visit(node)

    def visit_For(self, node: ast.For) -> None:  # noqa: N802
        self.loop_depth += 1
        self.generic_visit(node)
        self.loop_depth -= 1

    def visit_AsyncFor(self, node: ast.AsyncFor) -> None:  # noqa: N802
        self.loop_depth += 1
        self.generic_visit(node)
        self.loop_depth -= 1

    def visit_While(self, node: ast.While) -> None:  # noqa: N802
        self.loop_depth += 1
        self.generic_visit(node)
        self.loop_depth -= 1

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:  # noqa: N802
        name = dotted_name(node.type).split(".")[-1]
        if name == "BaseException":
            self.add(
                "critical",
                "SWALLOWED_BASE_EXCEPTION",
                node,
                "BaseException handler may trap ADK interruption/cancellation; remove or re-raise after cleanup.",
            )
        elif name == "Exception" or node.type is None:
            self.add(
                "attention",
                "BROAD_EXCEPTION",
                node,
                "Broad exception handler: confirm it cannot hide retryable failures or workflow interruption semantics.",
            )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
        call = called_name(node)
        short = call.split(".")[-1]

        if short == "enqueue_event":
            self.add(
                "critical",
                "DIRECT_EVENT_ENQUEUE",
                node,
                "Direct enqueue_event call: emit by returning/yielding Event through the runtime.",
            )
        if short == "append" and ".events.append" in call:
            self.add(
                "critical",
                "DIRECT_EVENT_APPEND",
                node,
                "Direct session event append bypasses workflow runtime ownership and persistence.",
            )
        if self.loop_depth and short in {"run", "run_async", "run_live"}:
            self.add(
                "attention",
                "RUNNER_LOOP",
                node,
                "Runner call inside a loop: decide whether this is independent request batching or durable workflow control.",
            )

        keys = keyword_names(node)
        for keyword in node.keywords:
            if keyword.arg != "instruction" or not isinstance(keyword.value, ast.Constant):
                continue
            if isinstance(keyword.value.value, str) and PROMPT_CONTROL_PATTERN.search(keyword.value.value):
                self.add(
                    "info",
                    "PROMPT_CONTROL_LANGUAGE",
                    keyword.value,
                    "Instruction may encode runtime order/routing; extract product invariants but retain task explanation and semantic judgment.",
                )
        if "sub_agents" in keys:
            self.add(
                "info",
                "SUB_AGENTS",
                node,
                "Collaborative sub_agents topology found; retain when agentic delegation is intentional, otherwise review control policy.",
            )
        if short in {"SequentialAgent", "ParallelAgent", "LoopAgent"}:
            self.add(
                "info",
                "TEMPLATE_WORKFLOW",
                node,
                f"{short} is a supported template workflow candidate, not an automatic graph rewrite.",
            )
        if short == "Workflow":
            self.add(
                "info",
                "GRAPH_WORKFLOW",
                node,
                "Graph Workflow construction found; validate terminal outputs, joins, routes, schemas, and target-runtime support.",
            )
        if short == "JoinNode":
            self.add(
                "info",
                "JOIN_NODE",
                node,
                "JoinNode found; verify every predecessor produces the documented aggregation value.",
            )
        if short == "RetryConfig":
            self.add(
                "info",
                "RETRY_CONFIG",
                node,
                "RetryConfig found; verify exception names/types, bounds, and idempotency of retried side effects.",
            )
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:  # noqa: N802
        if node.id in {"ToolContext", "CallbackContext"}:
            self.add(
                "attention",
                "LEGACY_CONTEXT_TYPE",
                node,
                f"{node.id} reference: verify and migrate to the unified Context API for the pinned 2.x release.",
            )
        self.generic_visit(node)


def iter_project_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        if path.is_file() and (path.suffix == ".py" or path.name in MANIFEST_NAMES):
            yield path


def audit_python(path: Path, relative_path: str) -> list[Finding]:
    try:
        source = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        return [Finding("attention", "FILE_READ_ERROR", relative_path, 1, str(exc))]
    try:
        tree = ast.parse(source, filename=relative_path)
    except SyntaxError as exc:
        return [
            Finding(
                "attention",
                "PYTHON_PARSE_ERROR",
                relative_path,
                exc.lineno or 1,
                exc.msg,
            )
        ]
    audit = PythonAudit(relative_path)
    audit.visit(tree)
    return audit.findings


DEPENDENCY_PATTERN = re.compile(
    r"(?im)^.*(?:google-adk|google\.adk).*$"
)


def audit_manifest(path: Path, relative_path: str) -> list[Finding]:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        return [Finding("attention", "FILE_READ_ERROR", relative_path, 1, str(exc))]

    findings: list[Finding] = []
    for match in DEPENDENCY_PATTERN.finditer(text):
        line = text.count("\n", 0, match.start()) + 1
        statement = match.group(0).strip()
        findings.append(
            Finding(
                "info",
                "ADK_DEPENDENCY",
                relative_path,
                line,
                f"ADK dependency/reference: {statement[:180]}",
            )
        )
    if path.name == "agents-cli-manifest.yaml":
        findings.append(
            Finding(
                "info",
                "AGENTS_CLI_MANAGED",
                relative_path,
                1,
                "Agents CLI manifest found; scaffold upgrade may apply, but remains separate from application-code migration.",
            )
        )
    if re.search(r"additionalProperties\s*[:=]\s*false", text, re.IGNORECASE):
        findings.append(
            Finding(
                "attention",
                "RIGID_SCHEMA",
                relative_path,
                1,
                "Rigid schema marker found; inspect Event/client schemas for ADK 2 node_info and output fields.",
            )
        )
    return findings


def collect(root: Path) -> tuple[list[Finding], int, int]:
    findings: list[Finding] = []
    python_count = 0
    manifest_count = 0
    for path in iter_project_files(root):
        relative_path = path.relative_to(root).as_posix()
        if path.suffix == ".py":
            python_count += 1
            findings.extend(audit_python(path, relative_path))
        else:
            manifest_count += 1
            findings.extend(audit_manifest(path, relative_path))
    findings.sort(
        key=lambda item: (
            SEVERITY_RANK[item.severity],
            item.path,
            item.line,
            item.code,
        )
    )
    return findings, python_count, manifest_count


def summary(findings: Sequence[Finding]) -> dict[str, int]:
    result = {severity: 0 for severity in SEVERITY_RANK}
    for finding in findings:
        result[finding.severity] += 1
    return result


def markdown_report(root: Path, findings: Sequence[Finding], py_count: int, manifest_count: int) -> str:
    counts = summary(findings)
    lines = [
        "# ADK 1.x → 2.x migration audit",
        "",
        f"Root: `{root}`",
        f"Scanned: {py_count} Python files and {manifest_count} manifest files.",
        f"Findings: {counts['critical']} critical, {counts['attention']} attention, {counts['info']} info.",
        "",
        "> Static findings are review leads, not proof and not automatic rewrite instructions.",
        "",
    ]
    if not findings:
        lines.append("No scanner findings. This does not prove compatibility; complete the manual inventory and tests.")
        return "\n".join(lines)

    lines.extend(
        [
            "| Severity | Code | Location | Finding |",
            "| --- | --- | --- | --- |",
        ]
    )
    for item in findings:
        message = item.message.replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| {item.severity} | `{item.code}` | `{item.path}:{item.line}` | {message} |"
        )
    return "\n".join(lines)


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=".", help="Project root (default: current directory)")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument(
        "--fail-on",
        choices=("never", "critical", "attention", "info"),
        default="never",
        help="Return exit status 2 when this severity or a more severe finding exists.",
    )
    return parser.parse_args(argv)


def should_fail(findings: Sequence[Finding], threshold: str) -> bool:
    if threshold == "never":
        return False
    maximum_rank = SEVERITY_RANK[threshold]
    return any(SEVERITY_RANK[item.severity] <= maximum_rank for item in findings)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    root = Path(args.root).expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 1

    findings, py_count, manifest_count = collect(root)
    if args.format == "json":
        payload = {
            "root": str(root),
            "scanned": {"python_files": py_count, "manifest_files": manifest_count},
            "summary": summary(findings),
            "findings": [asdict(item) for item in findings],
            "disclaimer": "Static findings are review leads, not proof or automatic rewrite instructions.",
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(markdown_report(root, findings, py_count, manifest_count))
    return 2 if should_fail(findings, args.fail_on) else 0


if __name__ == "__main__":
    raise SystemExit(main())
