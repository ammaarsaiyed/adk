# ADK Python 1.x → 2.x breaking-change review

This checklist is based on Google's ADK 2.0 compatibility guide and was last reviewed on 2026-09-07. Revalidate against the exact selected release.

## Confirmed 2.0 compatibility surfaces

| Surface | 1.x risk | 2.x migration action | Evidence to collect |
| --- | --- | --- | --- |
| Event schema | Rigid stores/clients know only 1.x fields | Accept and preserve `node_info` and `output`; update strict validators | Storage round trip plus every strict client/schema test |
| Custom `BaseSessionService` | ORM columns or serializers reject/drop new fields | Expand schema/readers before 2.x writers; use additive rollout | Mixed-version read/write test and rollback path |
| Custom `BaseAgent` execution | Overrides such as `_run_async_impl()` or `generate_content()` may be bypassed by workflow execution | Move lifecycle logic to supported before/after callbacks; express orchestration as nodes/workflow | Callback/node tests proving logic runs exactly once as intended |
| Direct event list mutation | `context.session.events.append(...)` bypasses runtime routing/persistence | Return or yield `Event` from the executing node/agent | Event stream and persistence test |
| `enqueue_event` application use | Manually injected events bypass workflow ownership | Emit through the runtime | Same as above |
| Broad exception handling | `except Exception` can hide failures from `RetryConfig`; `BaseException` can trap interruption | Catch only errors resolved locally; re-raise or let retryable failures propagate; never swallow `BaseException` | Retry, terminal-error, and HITL interruption tests |
| Context types | Python docs unify former callback/tool contexts into `Context` | Check exact callback/tool signatures and migrate annotations/imports without losing capabilities | Import/type test and focused callback/tool tests |
| Session database v0 | Older pickle schema has a separate 1.x-era migration path | If still on v0, use the official `adk migrate session` process to a separate destination before the 2.x cutover | Backup, dry run, row/event counts, application read test |

## Session rollout order

Treat persistent event/session schema as expand–migrate–contract:

1. Back up and prove restore.
2. Expand storage and validators to accept old and new event shapes.
3. Deploy readers that tolerate 2.x fields.
4. Validate mixed-version behavior. Google states 2.0 sessions are readable by ADK 1.28+ while older 1.x versions are incompatible; verify the exact versions in the selected release notes.
5. Deploy 2.x writers to a canary or isolated environment.
6. Observe serialization, event counts, replay, and client errors.
7. Contract old compatibility only after rollback is no longer required.

Do not rewrite a production session database in place without a recoverable copy. The older `DatabaseSessionService` v0→v1 migration writes to a destination database; keep source and destination distinct during validation.

## Scoped negative constraints

These are bans because they break the 2.x runtime model:

- direct session event append;
- direct application use of `enqueue_event` for emission;
- swallowed `BaseException`;
- assuming custom execution overrides run without a test;
- persisting 2.x Events into a rigid 1.x schema;
- ending a multi-output parallel graph without a join/aggregation node.

These are review triggers, not bans:

- `sub_agents`;
- `Runner` or `run_async`;
- `SequentialAgent`, `ParallelAgent`, `LoopAgent`;
- session state dictionaries;
- `except Exception` that performs narrow local recovery and then returns a valid domain result;
- existing import paths that still resolve in the pinned 2.x version.

## Import pass rules

- Update only symbols proven incompatible by the pinned environment or official tagged source.
- Prefer public top-level exports where documented: `Agent`, `Context`, `Event`, `Runner`, and `Workflow` from `google.adk`.
- Import workflow-only helpers such as `START`, `DEFAULT_ROUTE`, `JoinNode`, `RetryConfig`, and `node` from `google.adk.workflow` when verified for the target version.
- Do not invent `google.adk.workflows` or a universal `@node(ctx) -> dict patch` convention. In documented Python 2.x, function-node parameters are resolved by signature, `node_input` receives predecessor output, `Context` can be injected, and nodes may return ordinary values or Events.
- Keep an import-only change separate from behavior redesign so failures are diagnosable.

## Error-handling conversion

For every tool/node that catches broadly, classify the exception:

- **Locally recoverable:** catch the narrow class, repair/fallback, return a truthful domain result.
- **Retryable transient:** let it propagate and attach a bounded `RetryConfig` naming appropriate exception classes.
- **Terminal domain failure:** convert to a typed/domain result only if that is part of the public contract; otherwise propagate.
- **Cancellation/interruption:** never swallow; allow the runtime to pause/cancel.

Retry only idempotent operations or operations protected by an idempotency key. Automatic retry around an unprotected charge, booking, email, or mutation can duplicate the side effect.
