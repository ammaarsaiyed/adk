# Discovery and baseline

Use this before touching the dependency or source. The goal is to establish what must remain true and what can change.

## 1. Read project instructions and preserve the worktree

- Read repository-level and nested `AGENTS.md`, `GEMINI.md`, `CLAUDE.md`, and contributor guidance that applies to files in scope.
- Inspect version-control status. Preserve unrelated user changes and do not reset or overwrite them.
- Identify the real project root, package manager, supported Python versions, and CI entry points.
- Determine whether Agents CLI manages the scaffold by checking for `agents-cli-manifest.yaml` and `agents-cli info`; do not infer this from directory shape alone.

## 2. Record the version facts

Capture evidence from manifests, lockfiles, and the active runtime:

```bash
rg -n --glob 'pyproject.toml' --glob 'requirements*.txt' --glob 'uv.lock' --glob 'poetry.lock' 'google-adk|google\.adk'
python -c 'import importlib.metadata as m; print(m.version("google-adk"))'
python --version
```

Record the current exact version, proposed exact 2.x version, resolver/lockfile, Python range, and deployment image/runtime version. A broad dependency spec is not evidence of what production runs.

## 3. Inventory observable surfaces

Find and classify:

- root agents and alternate entry points;
- tool functions, tool wrappers, auth/confirmation paths, and external side effects;
- `sub_agents`, `AgentTool`, template workflow agents, custom agents, and runner loops;
- callbacks, plugins, direct event manipulation, and custom streaming behavior;
- session services, event storage, state prefixes, artifact/memory services, and schema migrations;
- REST/WebSocket clients, strict JSON schemas, generated SDKs, and analytics pipelines consuming Events;
- eval datasets, integration tests, mocks, golden traces, and production telemetry;
- Cloud Run, Agent Runtime/legacy Agent Engine, GKE, custom server, or local-only deployment files.

Use the bundled scanner, then confirm findings with focused searches such as:

```bash
rg -n 'BaseAgent|_run_async_impl|generate_content|session\.events|enqueue_event'
rg -n 'ToolContext|CallbackContext|ReadonlyContext|InvocationContext|Context'
rg -n 'sub_agents|SequentialAgent|ParallelAgent|LoopAgent|Runner|run_async'
rg -n 'BaseSessionService|DatabaseSessionService|additionalProperties|Event'
rg -n 'except +(BaseException|Exception)' --glob '*.py'
```

Also inspect agent instructions for possible prompt-encoded control terms such as `first`, `then`, `only after`, `must call`, `delegate`, and conditional business rules. These are leads: distinguish required product control from task explanation and semantic judgment before moving anything into a graph.

## 4. Establish a judge-first baseline

Prefer existing public-surface tests. If they are insufficient, assemble the smallest portable parity harness that observes:

- final user-facing response shape and structured outputs;
- tool selection, arguments, confirmations, and side effects;
- state changes by scope (`app:`, `user:`, `temp:`, and session-local);
- emitted event types/order only where consumers rely on them;
- handoff/return behavior between agents;
- interruption, resume, retry, timeout, and duplicate-side-effect behavior;
- client serialization and persistence round trips.

For LLM behavior, use an eval dataset with explicit criteria and tolerances. Do not assert exact prose unless the product contract requires exact prose. Seed or stub deterministic dependencies where supported, but do not call a stochastic model “deterministic.”

Validate a newly built harness before trusting it: run it against the 1.x baseline, then introduce one small reversible defect or use a known negative fixture and confirm the harness fails for the intended reason. Remove the defect immediately.

## 5. Produce the discovery artifacts

Before Plan or Implement proceeds, write:

1. **Inventory:** files and runtime surfaces affected.
2. **Behavior contract:** what must stay the same; explicitly list approved changes.
3. **Risk register:** session/event compatibility, replay/side effects, routing, clients, cloud runtime, and dependency risks.
4. **Judge:** exact commands/datasets and current results, including inherited failures.
5. **Unknowns:** facts that require a user decision or official-version verification.

If the requested target version, production data path, or behavior contract remains materially ambiguous, stop and ask for the choice rather than designing around a guess.
