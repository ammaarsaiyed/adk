# ADK 2.x Python API and migration patterns

Verify each pattern against the project's pinned ADK 2.x release before editing. These patterns describe the 2.0 model; they are not a substitute for tagged API signatures.

## Function nodes and typed dataflow

Plain functions can be nodes in chain-tuple edges. The runtime binds `node_input` from the predecessor, injects `Context` into a `ctx`/typed parameter, and resolves other parameters from state by default.

```python
from pydantic import BaseModel
from google.adk import Context, Workflow
from google.adk.workflow import START

class SearchResult(BaseModel):
    ids: list[str]

def search(node_input: str) -> SearchResult:
    return SearchResult(ids=[node_input])

def persist_selection(ctx: Context, node_input: SearchResult) -> SearchResult:
    ctx.state["last_ids"] = node_input.ids
    return node_input

root_agent = Workflow(
    name="search_workflow",
    edges=[(START, search, persist_selection)],
)
```

Use `@node(...)` when wrapper options such as name, schema, retry, timeout, parameter binding, or resume behavior are needed. Do not decorate every function mechanically.

## Output, user messages, routes, and state

These are separate channels:

- ordinary return value or `Event(output=value)` → downstream node data;
- `Event(message=...)` → user-visible content;
- `Event(route=...)` → conditional edge selection;
- `Event(state={...})` or `ctx.state[...]` → shared/persistent state.

Do not assume a terminal `Event(output=...)` is visible in the Web UI. Emit a message when the user must see it.

```python
from google.adk import Event

async def summarize(node_input: str):
    result = f"Summary: {node_input}"
    yield Event(message=result)
    yield Event(output=result)
```

## Conditional routing

```python
from google.adk import Event, Workflow
from google.adk.workflow import DEFAULT_ROUTE, START

def route_request(node_input: str):
    route = "approved" if is_approved(node_input) else "rejected"
    return Event(route=route, output=node_input)

root_agent = Workflow(
    name="approval_flow",
    edges=[
        (START, route_request),
        (route_request, {
            "approved": fulfill,
            "rejected": explain_rejection,
            DEFAULT_ROUTE: handle_unknown,
        }),
    ],
)
```

Route by deterministic code when the rule is a policy. Use an LLM router only when semantic judgment is genuinely required, then add eval cases for ambiguity and fallback behavior.

## Parallel fan-out and join

```python
from google.adk import Workflow
from google.adk.workflow import JoinNode, START

gather = JoinNode(name="gather")

root_agent = Workflow(
    name="parallel_research",
    edges=[
        (START, (research_a, research_b, research_c), gather, synthesize),
    ],
    max_concurrency=3,
)
```

Every branch feeding a join must produce output. The join passes a mapping keyed by predecessor node name. Cap concurrency to protect rate limits and connection pools. Give distinct node instances unique names.

## Dynamic durable orchestration

Use when runtime logic is clearer as Python:

```python
from google.adk import Context, Workflow
from google.adk.workflow import START, node

@node(name="process_item")
async def process_item(node_input: Item) -> Result:
    return await call_service(node_input)

@node(name="batch_orchestrator", rerun_on_resume=True)
async def batch_orchestrator(ctx: Context, node_input: list[Item]) -> list[Result]:
    results = []
    for item in node_input:
        results.append(await ctx.run_node(process_item, node_input=item))
    return results

root_agent = Workflow(
    name="batch_workflow",
    edges=[(START, batch_orchestrator)],
)
```

An orchestrator that calls `ctx.run_node()` must use re-entry on resume so completed child activations replay from checkpoints instead of running their side effects again. Still design child side effects for idempotency and test an actual interrupt/resume path.

## Retries

```python
from google.adk.workflow import RetryConfig, node

transient_retry = RetryConfig(
    max_attempts=3,
    initial_delay=1.0,
    backoff_factor=2.0,
    max_delay=10.0,
    jitter=0.2,
    exceptions=["TimeoutError", "ConnectionError"],
)

@node(name="fetch_remote", retry_config=transient_retry)
async def fetch_remote(node_input: str) -> str:
    return await client.fetch(node_input)
```

Confirm exact field types for the target version. Under tests, use low delays and `jitter=0.0`. Do not retry non-idempotent side effects without deduplication.

## Collaborative subagents

```python
from google.adk import Agent

lookup = Agent(
    name="lookup",
    mode="single_turn",
    input_schema=LookupInput,
    output_schema=LookupResult,
    tools=[search_catalog],
)

root_agent = Agent(
    name="coordinator",
    instruction="Delegate catalog lookups to lookup.",
    sub_agents=[lookup],
)
```

Use collaboration when agentic delegation is intentional. Mode semantics in the initial 2.0 docs include `chat`, `task`, and `single_turn`, with constraints such as task agents being leaves and task mode being disabled in graph workflows in Python 2.0.0. These limitations are version-sensitive; verify them against the pinned release.

## Mapping legacy structures

| 1.x structure | 2.x choice | Migration note |
| --- | --- | --- |
| Ordinary `LlmAgent` + tools | Keep agent | Upgrade compatibility surfaces; graph not required |
| `SequentialAgent` | Keep template or static chain | Choose graph for typed flow, routes, retry, HITL, or nesting |
| `ParallelAgent` + state aggregation | Keep template or fan-out + `JoinNode` | Make every branch output contract explicit |
| `LoopAgent` | Keep bounded template loop or dynamic workflow | Prefer dynamic workflow for complex/data-dependent iteration |
| `sub_agents` transfer topology | Keep collaboration or replace policy-critical transfers with routes | `sub_agents` is not forbidden in ADK 2.x |
| Manual runner loop | Dynamic workflow or external batch controller | Decide whether the loop is durable workflow control or independent request concurrency |
| Session dict used as pipeline bus | Typed node input/output | Retain state only for real scoped persistence/shared values |
| Custom `BaseAgent` scheduler | Workflow/dynamic node + callbacks | Prove lifecycle and event emission in tests |
| Manual event append | yield/return `Event` | Let runtime own persistence, routing, and streaming |

## Common false migrations

- Importing `START` from `google.adk`; documented examples import it from `google.adk.workflow`.
- Returning a LangGraph-style dictionary patch from every node. ADK Python nodes may return ordinary typed values; state updates are a separate mechanism.
- Replacing every `Runner`. A `Workflow` is still run through a Runner like an agent.
- Assuming `output` is user-visible content.
- Leaving multiple output-producing terminal nodes after fan-out.
- Converting every loop into a cyclic static graph when a dynamic workflow is clearer.
