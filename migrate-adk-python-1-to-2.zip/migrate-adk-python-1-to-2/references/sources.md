# Sources and version-verification map

API and compatibility facts in this skill were reviewed on 2026-09-07. ADK is moving quickly; verify the selected tag and installed package before editing a project.

## Primary ADK sources

Use these as authority, preferably at the tag matching the target release:

- [ADK documentation](https://adk.dev/) — documentation hub and language/version navigation.
- [ADK 2.0 overview and compatibility guidance](https://adk.dev/2.0/) — release status, compatibility, Event/session changes, custom-agent behavior, event emission, and exception/interruption guidance.
- [Graph workflows](https://adk.dev/graphs/) — static graphs, dynamic workflows, and retained prebuilt workflow-agent options.
- [Graph routes](https://adk.dev/graphs/routes/) — conditional routing, route labels, defaults, and joins.
- [Graph data handling](https://adk.dev/graphs/data-handling/) — node inputs/outputs, Events, messages, routes, state, and schemas.
- [Dynamic workflows](https://adk.dev/graphs/dynamic/) — `@node`, `Context.run_node()`, checkpoint replay, and resume re-entry.
- [Agent collaboration](https://adk.dev/workflows/collaboration/) — supported `sub_agents` topology and mode constraints.
- [Workflow patterns](https://adk.dev/workflows/patterns/) — 1.x-era sequential, parallel, loop, and coordinator patterns; evidence that workflow agents predate 2.0.
- [Runtime context](https://adk.dev/context/) — unified Python `Context` and context capabilities.
- [Session migration](https://adk.dev/sessions/session/migrate/) — the separate legacy `DatabaseSessionService` v0→v1 process.
- [Agent Runtime deployment](https://adk.dev/deploy/agent-runtime/) — supported packaging/deployment path and current constraints.
- [`google/adk-python`](https://github.com/google/adk-python) — tagged source, release notes, API surface, and bundled developer guides.
- [`google/adk-samples`](https://github.com/google/adk-samples) — official reference implementations; match samples to the target release.
- [`google/agents-cli`](https://github.com/google/agents-cli) — official lifecycle skills and scaffold tooling. `scaffold upgrade` updates an Agents CLI scaffold; it is not a general ADK application codemod.

When a current guide conflicts with a pinned tag, prefer the pinned tag for code and explicitly document the discrepancy. When the installed package conflicts with assumptions, inspect its signatures and fail with a targeted question instead of guessing.

## Process-pattern sources

These informed the migration process, not ADK API claims:

- [Anthropic code migration kit](https://github.com/anthropics/code-migration-kit-with-claude-code) — feasibility first, judge-before-translation, behavioral units, and evidence gates.
- [Deprecation and migration skill](https://github.com/addyosmani/agent-skills/tree/main/skills/deprecation-and-migration) — incremental migration, explicit forbidden shortcuts, and verification discipline.
- [Quarkus migration skills](https://github.com/quarkusio/skills) — systematic framework mapping and build validation.
- [Koin migration skill](https://github.com/InsertKoinIO/koin-migration) — concise orchestrator plus on-demand reference files.
- [Swift Concurrency Agent Skill](https://github.com/AvdLee/Swift-Concurrency-Agent-Skill) — strict-compiler migration gates and portable Agent Skills packaging.
- [Tuist agent skills](https://github.com/tuist/agent-skills) — codebase audit and validation-loop patterns.
- [LangChain migration guides](https://python.langchain.com/docs/versions/v0_2/) and [LangGraph documentation](https://langchain-ai.github.io/langgraph/) — conceptual examples of making control state explicit. Do not copy LangGraph node signatures or semantics into ADK.
- [Agent Skills specification](https://github.com/skillsmd/skills.md) — portable `SKILL.md` packaging conventions.

Community rules, codemods, and framework migrations may suggest useful process patterns but are never evidence that an ADK symbol exists or that two runtimes have equivalent semantics.
