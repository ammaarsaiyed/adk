# Verification, rollout, and rollback

Verification must prove the behavior contract selected during discovery. Compilation is necessary, never sufficient.

## Test ladder

Run the narrowest deterministic checks first, then widen:

1. **Static checks:** dependency resolution, imports, formatting/lint, type checking, and graph construction/schema validation.
2. **Node and tool units:** typed inputs/outputs, state scopes, route labels, error classification, idempotency keys, and callback execution.
3. **Workflow integration:** complete paths, default routes, parallel fan-in, termination, timeout, retry exhaustion, interrupt, and resume.
4. **Persistence and clients:** old/new Event serialization, custom session service round trips, strict API clients, streaming consumers, and analytics ingestion.
5. **Agent evaluations:** tool choice, arguments, delegation, structured output, refusal/approval behavior, and response-quality rubrics over a representative dataset.
6. **Deployment-equivalent smoke:** build the real artifact and start it with the target Python/runtime configuration and non-production dependencies.

Record exact commands, target version, environment, pass/fail counts, and skipped checks. Compare against inherited baseline failures rather than silently relabeling them.

## Required workflow cases

For every applicable workflow, cover:

- each conditional route, including `DEFAULT_ROUTE` or an intentional unknown-route failure;
- branch outputs and the `JoinNode` aggregation contract;
- zero, one, and many-item dynamic iterations;
- the maximum concurrency boundary and downstream rate-limit behavior;
- retryable, non-retryable, and exhausted failures;
- an interruption after at least one side-effecting child completes, followed by resume;
- termination for every loop and cycle, including a hard bound;
- duplicate delivery/replay with idempotency protection;
- user-visible `message` versus downstream `output` behavior.

Use fakes for external systems in unit tests, then run at least one authorized integration path when credentials and scope permit. Never substitute a mock-only result for proof that production serialization or deployment packaging works.

## Compatibility and data gates

Before any 2.x writer reaches shared persistent storage:

- back up the source and prove restore or clone it to a disposable target;
- deploy/read-test tolerant schemas and consumers first;
- round-trip representative 1.x and 2.x Events without dropping `node_info` or `output`;
- test the lowest supported rollback reader against data written by the canary;
- compare session/event counts, ordering requirements, state scopes, and payload sizes;
- document whether old binaries can safely read new sessions.

If a legacy `DatabaseSessionService` v0→v1 migration is also needed, treat it as a separate data migration with its own dry run and rollback. Do not combine an irreversible store rewrite with the orchestration redesign.

## Safe rollout patterns

Choose the lightest pattern proportionate to risk:

| Risk | Rollout | Required rollback |
| --- | --- | --- |
| Stateless compatibility-only upgrade | Staging smoke, then small canary | Redeploy pinned 1.x artifact |
| Event/client schema change | Expand readers, canary writers, observe, then widen | Stop 2.x writers and retain compatible readers |
| Workflow redesign without irreversible side effects | Feature flag or request-level cohort | Route traffic to legacy path |
| Workflow redesign with durable side effects | Shadow only where safe, then idempotent canary | Stop new starts; define handling for in-flight activations |
| Session database migration | Backup/clone, dry run, validation, controlled cutover | Restore/switch back using the rehearsed procedure |

Never shadow calls that would duplicate external mutations. Compare decisions or planned actions instead, or place side effects behind a dry-run adapter.

## Completion criteria

A migration report must include:

- source and target ADK/Python versions;
- architecture choice for each migrated boundary and any intentionally retained 1.x-era template/collaboration pattern;
- files, schemas, clients, and deployment surfaces changed;
- baseline and final evidence with exact commands;
- event/session compatibility result;
- resume/retry/idempotency result;
- remaining risks, unsupported integrations, and deferred work;
- cutover and executable rollback instructions.

Use precise status labels: **complete**, **complete with documented exceptions**, **blocked**, or **audit/plan only**. Do not claim behavior parity when the relevant eval, integration, persistence, or resume test was not run.
