# Migration reasoning traps

Use this table during design and review. It rejects both lazy compatibility work and overzealous rewrites.

| Tempting shortcut or claim | Why it fails | Required response |
| --- | --- | --- |
| “Convert every `sub_agents` list.” | ADK 2.x explicitly supports collaborative coordinators and `chat`, `task`, and `single_turn` subagent modes. | Convert fixed policy pipelines; retain intentional agentic delegation and test its mode semantics. |
| “Every instruction containing ‘first’ or ‘if’ must become a graph.” | Those words can describe a task, not control the runtime. Mechanical extraction creates needless topology. | Identify the underlying invariant; graph required order/policy, evaluate semantic judgment. |
| “The graph makes the application deterministic.” | Edges and code routes can be deterministic; LLM nodes, tools, networks, and concurrency may not be. | Test topology deterministically and evaluate generative behavior with datasets and tolerances. |
| “All nodes should take `Context` and return a dictionary patch.” | That copies LangGraph semantics. ADK function nodes can accept `node_input`, receive injected parameters, and return typed values or Events. | Use the pinned ADK node contract and separate data output, messages, routes, and state. |
| “Add `tool_context: Optional[Context] = None` to every tool.” | Tools that do not need runtime context should not gain it; making injected context optional can hide configuration/signature mistakes. | Add the documented pinned-version context parameter only where a tool needs state, auth, artifacts, memory, or confirmation. |
| “Use `TaskAgent`/`StepNode`/`WorkflowRuntime` because the names sound like the Task and Workflow APIs.” | These names are not the documented Python 2.0 constructs in the reviewed official examples. | Verify every import against the installed target; use `Agent(mode=...)`, `Workflow`, function/agent nodes, and `Runner` where documented. |
| “Import from `google.adk.workflows`.” | The reviewed Python graph helpers live under `google.adk.workflow` (singular), while core exports such as `Workflow` are documented at `google.adk`. | Prove imports in an isolated environment pinned to the exact target. |
| “Replace every store with an asyncpg provider.” | Backend choice is a deployment decision, not a universal ADK migration rule; plausible provider names may not exist. | Preserve the existing backend where supported, expand Event compatibility, and choose a new backend only from official target-version docs. |
| “Runner calls are legacy and must disappear.” | A `Workflow` still executes through a Runner, and external batching may legitimately call it repeatedly. | Replace only loops that emulate durable workflow control; keep ordinary invocation/batching with concurrency and isolation tests. |
| “Match the exact 1.x internal trajectory.” | A justified redesign intentionally changes internal steps, and stochastic agents may not repeat exact paths. | Judge the agreed public behavior, tools/side effects, policy routes, schemas, and quality tolerances. |
| “Imports and unit tests pass, so migration is complete.” | Session clients, replay, retries, streaming, deployment packaging, and evaluations can still fail. | Complete the verification ladder and report unrun gates explicitly. |
| “Update snapshots or loosen assertions until green.” | This can erase the behavior contract rather than prove the migration. | Explain intended contract changes; preserve independent baseline evidence and classify inherited failures. |

Absolute bans belong only to confirmed runtime/safety invariants such as direct session-event mutation, swallowed interruption, incompatible persistent schemas, and unjoined parallel terminal outputs. Treat architectural constructs as evidence to classify, not tokens to delete.
