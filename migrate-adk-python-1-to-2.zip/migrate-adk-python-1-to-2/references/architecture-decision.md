# Architecture decision: upgrade versus redesign

ADK 2.x supports several complementary orchestration styles. Choose per subsystem. “Newest” is not itself a design criterion.

## Classify control before choosing a primitive

| Logic kind | Typical evidence | Target treatment |
| --- | --- | --- |
| Product invariant | Required order, authorization, money/side-effect gate, retry/timeout policy, compliance rule, hard termination | Deterministic code, route, edge, workflow boundary, or human approval |
| Data transformation | Parsing, validation, normalization, aggregation, schema conversion | Typed function node or ordinary code |
| Generative judgment | Summarization, research, ambiguous intent, synthesis, open-ended planning | `Agent`/`LlmAgent` node with schemas, bounded tools, and eval coverage |
| Agentic delegation | Product intentionally allows a coordinator to choose specialists and iterate | Collaborative `sub_agents` topology with an appropriate mode |
| External request batching | Independent inputs share no durable control state | External async/batch controller may remain outside the workflow |
| Durable programmatic orchestration | Runtime-discovered items, loops, recursion, interrupt/resume, replay-sensitive steps | Dynamic workflow using `ctx.run_node()` |

Prompt phrases such as “first,” “then,” “only after,” “if,” and “delegate” are audit clues, not automatic rewrite commands. Extract a rule when it represents a product invariant. Leave explanatory procedure or genuinely semantic judgment in the agent instruction when a graph would not make the decision more correct or testable.

## Decision matrix

| Current intent | Recommended target | Why | Watch-outs |
| --- | --- | --- | --- |
| One agent reasons and chooses tools; no custom execution internals | Ordinary `Agent`/`LlmAgent` | 2.x remains compatible and a graph adds ceremony without control value | Still inspect contexts, events, exceptions, and session consumers |
| Existing fixed sequence/fan-out/bounded loop works and no graph-only feature is needed | Retain `SequentialAgent` / `ParallelAgent` / `LoopAgent` | These 1.x workflow agents already provided deterministic flow control and remain documented in Python | Consider graph migration later if explicit routing, typed dataflow, joins, or durable resume is needed |
| Fixed, inspectable topology with explicit order, branching, fan-out/fan-in, schemas, retry, or HITL | Static graph `Workflow` | Control flow belongs in edges; functions, tools, agents, and nested workflows are nodes | Static graphs can become awkward for iterative/runtime-dependent logic; parallel outputs need `JoinNode` |
| Runtime-discovered tasks, complex loops, recursion, data-dependent iteration, or durable programmatic control | Dynamic workflow | Ordinary Python control flow plus `ctx.run_node()` and checkpoints is clearer | Orchestrators calling `run_node()` need `rerun_on_resume=True`; side effects must be replay-safe |
| The product intentionally lets an LLM coordinator decide which specialist acts and allows adaptive delegation | Collaborative team with `sub_agents` and modes | Agentic delegation is the feature, not an accident | Mode constraints matter; task mode limitations must be rechecked for the selected release |
| Business process needs fixed control boundaries but benefits from LLM reasoning inside steps | Hybrid graph/dynamic workflow with agent nodes | Deterministic process shell, nondeterministic reasoning where useful | Define typed boundaries and evaluate agent nodes separately from graph mechanics |

## Architecture questions

For each orchestration boundary, answer:

1. Is the next step a product rule or a reasoning decision?
   - Product rule → encode it in an edge, router function, or Python control flow.
   - Reasoning decision → keep it in an agent, with eval coverage and bounded authority.
   - Mixed decision → let an agent produce a typed classification, then enforce policy with deterministic code.
2. Is the topology known before execution?
   - Yes → static graph is a candidate.
   - No, or depends on iterative results → dynamic workflow is a candidate.
3. Must completed work survive pause/resume without repeating side effects?
   - If yes, make node boundaries align with idempotent/checkpointable operations and test resume.
4. Is data transient within one run or persistent across turns/users?
   - Within-run → node input/output and Pydantic schemas.
   - Persistent/shared → correctly scoped session state or an external system of record.
5. Does a human interact with a specialist or approve a risky action?
   - Model the exact control-transfer and confirmation semantics; do not substitute a chat handoff for a task completion or workflow interrupt.
6. Does deployment or an integration support the selected workflow features?
   - Verify against the exact release and target before committing to the design.

## Redesign triggers

A compatibility-only upgrade is usually insufficient when the 1.x project uses:

- prompts as an implicit business-process engine (“always do A, then maybe B, never skip C”);
- repeated `Runner.run_async` calls or hand-written loops to emulate a durable process;
- custom `BaseAgent` overrides that schedule work or append events;
- shared session dictionaries as an untyped message bus between unrelated steps;
- coordinator delegation where compliance, money movement, authorization, or side-effect order must not depend on an LLM;
- unbounded or opaque agent-to-agent handoff loops;
- parallel work without an explicit aggregation contract;
- manual retry loops whose behavior must now cooperate with runtime retry and HITL.

## Design document for structural migrations

For any redesign, produce a small design document before code:

- current execution narrative and observable contract;
- chosen style and why each rejected style is worse for this boundary;
- nodes/agents, edge or dynamic control rules, and termination conditions;
- input/output/state schemas and event consumers;
- side-effect ownership and idempotency keys;
- retryable versus terminal errors;
- pause/resume semantics;
- rollout, dual-run/canary possibility, and rollback;
- verification scenarios.

Do not use file-by-file translation as the unit for a redesign. Use a behaviorally coherent subsystem so its public contract can be judged end to end.
